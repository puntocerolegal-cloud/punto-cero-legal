"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Loader2 } from "lucide-react"
import Link from "next/link"
import { Client } from "@/lib/types"

export default function NuevaFacturaPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [clients, setClients] = useState<Client[]>([])
  const [formData, setFormData] = useState({
    client_id: "",
    concepto: "",
    subtotal: "",
    iva: "19",
    fecha_vencimiento: "",
    notas: "",
  })

  useEffect(() => {
    const loadClients = async () => {
      const supabase = createClient()
      const { data } = await supabase
        .from("clients")
        .select("*")
        .order("nombre_completo")
      setClients(data || [])
    }
    loadClients()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const subtotal = parseFloat(formData.subtotal) || 0
  const ivaRate = parseFloat(formData.iva) / 100
  const ivaAmount = subtotal * ivaRate
  const total = subtotal + ivaAmount

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const supabase = createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      setError("No se pudo obtener el usuario")
      setLoading(false)
      return
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("law_firm_id")
      .eq("id", user.id)
      .single()

    if (!profile?.law_firm_id) {
      setError("No tienes una firma asociada")
      setLoading(false)
      return
    }

    // Generate invoice number
    const { count } = await supabase
      .from("invoices")
      .select("*", { count: "exact", head: true })
      .eq("law_firm_id", profile.law_firm_id)
    
    const invoiceNumber = `FAC-${String((count || 0) + 1).padStart(5, "0")}`

    const { error: insertError } = await supabase.from("invoices").insert({
      law_firm_id: profile.law_firm_id,
      client_id: formData.client_id,
      numero_factura: invoiceNumber,
      concepto: formData.concepto,
      subtotal: subtotal,
      iva: ivaAmount,
      total: total,
      fecha_emision: new Date().toISOString().split("T")[0],
      fecha_vencimiento: formData.fecha_vencimiento || null,
      notas: formData.notas || null,
      status: "pendiente",
    })

    if (insertError) {
      setError(insertError.message)
      setLoading(false)
    } else {
      router.push("/dashboard/facturas")
      router.refresh()
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/facturas">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Nueva factura</h1>
          <p className="text-muted-foreground">Crea una nueva factura para un cliente</p>
        </div>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Información de la factura</CardTitle>
          <CardDescription>Completa los datos de la nueva factura</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="client_id">Cliente *</Label>
              <Select
                value={formData.client_id}
                onValueChange={(value) => setFormData({ ...formData, client_id: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.nombre_completo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="concepto">Concepto *</Label>
              <Textarea
                id="concepto"
                name="concepto"
                value={formData.concepto}
                onChange={handleChange}
                placeholder="Descripción del servicio facturado"
                rows={2}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="subtotal">Subtotal (COP) *</Label>
                <Input
                  id="subtotal"
                  name="subtotal"
                  type="number"
                  value={formData.subtotal}
                  onChange={handleChange}
                  placeholder="0"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="iva">IVA (%)</Label>
                <Select
                  value={formData.iva}
                  onValueChange={(value) => setFormData({ ...formData, iva: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0% (Exento)</SelectItem>
                    <SelectItem value="5">5%</SelectItem>
                    <SelectItem value="19">19%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="bg-muted p-4 rounded-lg space-y-2">
              <div className="flex justify-between text-sm">
                <span>Subtotal:</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>IVA ({formData.iva}%):</span>
                <span>{formatCurrency(ivaAmount)}</span>
              </div>
              <div className="flex justify-between font-bold border-t pt-2">
                <span>Total:</span>
                <span>{formatCurrency(total)}</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fecha_vencimiento">Fecha de vencimiento</Label>
              <Input
                id="fecha_vencimiento"
                name="fecha_vencimiento"
                type="date"
                value={formData.fecha_vencimiento}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notas">Notas</Label>
              <Textarea
                id="notas"
                name="notas"
                value={formData.notas}
                onChange={handleChange}
                rows={2}
              />
            </div>

            <div className="flex gap-4 pt-4">
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  "Crear factura"
                )}
              </Button>
              <Button type="button" variant="outline" asChild>
                <Link href="/dashboard/facturas">Cancelar</Link>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
