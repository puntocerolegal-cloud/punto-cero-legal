import { createClient } from "@/lib/supabase/server"
import { FacturasTable } from "./facturas-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function FacturasPage() {
  const supabase = await createClient()
  const { data: invoices } = await supabase
    .from("invoices")
    .select("*, client:clients(nombre_completo)")
    .order("fecha_emision", { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Facturas</h1>
          <p className="text-muted-foreground">Gestiona la facturación y honorarios</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/facturas/nueva">
            <Plus className="mr-2 h-4 w-4" />
            Nueva factura
          </Link>
        </Button>
      </div>

      <FacturasTable invoices={invoices || []} />
    </div>
  )
}
