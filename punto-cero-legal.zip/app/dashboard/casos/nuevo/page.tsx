"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Loader2 } from "lucide-react"
import Link from "next/link"
import { Client, CaseStatus } from "@/lib/types"

const caseStatuses: { value: CaseStatus; label: string }[] = [
  { value: "nuevo", label: "Nuevo" },
  { value: "en_tramite", label: "En trámite" },
  { value: "admitido", label: "Admitido" },
  { value: "notificado", label: "Notificado" },
  { value: "contestado", label: "Contestado" },
  { value: "pruebas", label: "Pruebas" },
  { value: "alegatos", label: "Alegatos" },
  { value: "fallo_primera_instancia", label: "Fallo primera instancia" },
  { value: "apelacion", label: "Apelación" },
  { value: "fallo_segunda_instancia", label: "Fallo segunda instancia" },
  { value: "casacion", label: "Casación" },
  { value: "ejecutoriado", label: "Ejecutoriado" },
  { value: "archivado", label: "Archivado" },
]

export default function NuevoCasoPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [clients, setClients] = useState<Client[]>([])
  const [formData, setFormData] = useState({
    client_id: "",
    radicado: "",
    despacho: "",
    tipo_proceso: "",
    jurisdiccion: "Ordinaria",
    especialidad: "",
    demandante: "",
    demandado: "",
    cuantia: "",
    status: "nuevo" as CaseStatus,
    fecha_radicacion: "",
    descripcion: "",
  })

  useEffect(() => {
    const loadClients = async () => {
      const supabase = createClient()
      const { data } = await supabase
        .from("clients")
        .select("*")
        .order("nombre_completo")
      setClients(data || [])
    }
    loadClients()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const supabase = createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      setError("No se pudo obtener el usuario")
      setLoading(false)
      return
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("law_firm_id")
      .eq("id", user.id)
      .single()

    if (!profile?.law_firm_id) {
      setError("No tienes una firma asociada")
      setLoading(false)
      return
    }

    const { error: insertError } = await supabase.from("cases").insert({
      law_firm_id: profile.law_firm_id,
      client_id: formData.client_id,
      radicado: formData.radicado || null,
      despacho: formData.despacho || null,
      tipo_proceso: formData.tipo_proceso || null,
      jurisdiccion: formData.jurisdiccion,
      especialidad: formData.especialidad || null,
      demandante: formData.demandante || null,
      demandado: formData.demandado || null,
      cuantia: formData.cuantia ? parseFloat(formData.cuantia) : null,
      status: formData.status,
      fecha_radicacion: formData.fecha_radicacion || null,
      descripcion: formData.descripcion || null,
      abogado_id: user.id,
    })

    if (insertError) {
      setError(insertError.message)
      setLoading(false)
    } else {
      router.push("/dashboard/casos")
      router.refresh()
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/casos">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Nuevo caso</h1>
          <p className="text-muted-foreground">Registra un nuevo proceso judicial</p>
        </div>
      </div>

      <Card className="max-w-3xl">
        <CardHeader>
          <CardTitle>Información del caso</CardTitle>
          <CardDescription>Completa los datos del nuevo proceso</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="client_id">Cliente *</Label>
                <Select
                  value={formData.client_id}
                  onValueChange={(value) => setFormData({ ...formData, client_id: value })}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id}>
                        {client.nombre_completo}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Estado</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value as CaseStatus })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {caseStatuses.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="radicado">Radicado</Label>
                <Input
                  id="radicado"
                  name="radicado"
                  placeholder="Ej: 11001-31-03-001-2024-00001-00"
                  value={formData.radicado}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fecha_radicacion">Fecha de radicación</Label>
                <Input
                  id="fecha_radicacion"
                  name="fecha_radicacion"
                  type="date"
                  value={formData.fecha_radicacion}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="despacho">Despacho judicial</Label>
              <Input
                id="despacho"
                name="despacho"
                placeholder="Ej: Juzgado 1 Civil del Circuito de Bogotá"
                value={formData.despacho}
                onChange={handleChange}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tipo_proceso">Tipo de proceso</Label>
                <Input
                  id="tipo_proceso"
                  name="tipo_proceso"
                  placeholder="Ej: Ejecutivo singular"
                  value={formData.tipo_proceso}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="jurisdiccion">Jurisdicción</Label>
                <Select
                  value={formData.jurisdiccion}
                  onValueChange={(value) => setFormData({ ...formData, jurisdiccion: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Ordinaria">Ordinaria</SelectItem>
                    <SelectItem value="Contencioso Administrativa">Contencioso Administrativa</SelectItem>
                    <SelectItem value="Constitucional">Constitucional</SelectItem>
                    <SelectItem value="Especial">Especial</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="especialidad">Especialidad</Label>
                <Input
                  id="especialidad"
                  name="especialidad"
                  placeholder="Ej: Civil, Laboral"
                  value={formData.especialidad}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="demandante">Demandante</Label>
                <Input
                  id="demandante"
                  name="demandante"
                  value={formData.demandante}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="demandado">Demandado</Label>
                <Input
                  id="demandado"
                  name="demandado"
                  value={formData.demandado}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cuantia">Cuantía (COP)</Label>
              <Input
                id="cuantia"
                name="cuantia"
                type="number"
                placeholder="0"
                value={formData.cuantia}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="descripcion">Descripción del caso</Label>
              <Textarea
                id="descripcion"
                name="descripcion"
                value={formData.descripcion}
                onChange={handleChange}
                rows={4}
              />
            </div>

            <div className="flex gap-4 pt-4">
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  "Guardar caso"
                )}
              </Button>
              <Button type="button" variant="outline" asChild>
                <Link href="/dashboard/casos">Cancelar</Link>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
