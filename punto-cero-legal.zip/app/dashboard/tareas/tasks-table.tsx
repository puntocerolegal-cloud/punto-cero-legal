"use client"

import { useState } from "react"
import { Task } from "@/lib/types"
import { createClient } from "@/lib/supabase/client"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Edit } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface TasksTableProps {
  tasks: (Task & { case?: { radicado: string }; assignee?: { first_name: string; last_name: string } })[]
}

const priorityLabels: Record<string, string> = {
  baja: "Baja",
  media: "Media",
  alta: "Alta",
  urgente: "Urgente",
}

const priorityColors: Record<string, string> = {
  baja: "bg-gray-100 text-gray-800",
  media: "bg-blue-100 text-blue-800",
  alta: "bg-orange-100 text-orange-800",
  urgente: "bg-red-100 text-red-800",
}

export function TasksTable({ tasks }: TasksTableProps) {
  const router = useRouter()
  const [search, setSearch] = useState("")
  const [priorityFilter, setPriorityFilter] = useState<string>("all")
  const [showCompleted, setShowCompleted] = useState(false)

  const handleToggleComplete = async (taskId: string, completed: boolean) => {
    const supabase = createClient()
    await supabase
      .from("tasks")
      .update({ 
        completed, 
        completed_at: completed ? new Date().toISOString() : null 
      })
      .eq("id", taskId)
    router.refresh()
  }

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(search.toLowerCase())
    const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter
    const matchesCompleted = showCompleted || !task.completed
    return matchesSearch && matchesPriority && matchesCompleted
  })

  const isOverdue = (dueDate: string | null) => {
    if (!dueDate) return false
    return new Date(dueDate) < new Date() && !showCompleted
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar tareas..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Prioridad" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            {Object.entries(priorityLabels).map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <Checkbox
            id="showCompleted"
            checked={showCompleted}
            onCheckedChange={(checked) => setShowCompleted(checked as boolean)}
          />
          <label htmlFor="showCompleted" className="text-sm">
            Mostrar completadas
          </label>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]"></TableHead>
              <TableHead>Tarea</TableHead>
              <TableHead>Caso</TableHead>
              <TableHead>Asignado a</TableHead>
              <TableHead>Prioridad</TableHead>
              <TableHead>Fecha límite</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTasks.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  No se encontraron tareas
                </TableCell>
              </TableRow>
            ) : (
              filteredTasks.map((task) => (
                <TableRow key={task.id} className={task.completed ? "opacity-50" : ""}>
                  <TableCell>
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={(checked) => handleToggleComplete(task.id, checked as boolean)}
                    />
                  </TableCell>
                  <TableCell className={`font-medium ${task.completed ? "line-through" : ""}`}>
                    {task.title}
                  </TableCell>
                  <TableCell>{task.case?.radicado || "-"}</TableCell>
                  <TableCell>
                    {task.assignee
                      ? `${task.assignee.first_name} ${task.assignee.last_name}`
                      : "-"}
                  </TableCell>
                  <TableCell>
                    <Badge className={priorityColors[task.priority]}>
                      {priorityLabels[task.priority]}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {task.due_date ? (
                      <span className={isOverdue(task.due_date) ? "text-red-600 font-medium" : ""}>
                        {new Date(task.due_date).toLocaleDateString("es-CO")}
                      </span>
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" asChild>
                      <Link href={`/dashboard/tareas/${task.id}/editar`}>
                        <Edit className="h-4 w-4" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
