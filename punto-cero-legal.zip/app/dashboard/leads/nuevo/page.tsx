"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Loader2 } from "lucide-react"
import Link from "next/link"

const leadOrigins = [
  "Referido",
  "Página web",
  "Redes sociales",
  "Google",
  "Directorio",
  "Evento",
  "Publicidad",
  "Otro",
]

export default function NuevoLeadPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    telefono: "",
    empresa: "",
    origen: "",
    tipo_caso: "",
    mensaje: "",
    valor_estimado: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const supabase = createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      setError("No se pudo obtener el usuario")
      setLoading(false)
      return
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("law_firm_id")
      .eq("id", user.id)
      .single()

    if (!profile?.law_firm_id) {
      setError("No tienes una firma asociada")
      setLoading(false)
      return
    }

    const { error: insertError } = await supabase.from("leads").insert({
      law_firm_id: profile.law_firm_id,
      nombre: formData.nombre,
      email: formData.email || null,
      telefono: formData.telefono || null,
      empresa: formData.empresa || null,
      origen: formData.origen || null,
      tipo_caso: formData.tipo_caso || null,
      mensaje: formData.mensaje || null,
      valor_estimado: formData.valor_estimado ? parseFloat(formData.valor_estimado) : null,
      assigned_to: user.id,
      status: "nuevo",
    })

    if (insertError) {
      setError(insertError.message)
      setLoading(false)
    } else {
      router.push("/dashboard/leads")
      router.refresh()
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/leads">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Nuevo lead</h1>
          <p className="text-muted-foreground">Registra un nuevo prospecto de cliente</p>
        </div>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Información del lead</CardTitle>
          <CardDescription>Completa los datos del nuevo prospecto</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre completo *</Label>
              <Input
                id="nombre"
                name="nombre"
                value={formData.nombre}
                onChange={handleChange}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="telefono">Teléfono</Label>
                <Input
                  id="telefono"
                  name="telefono"
                  value={formData.telefono}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="empresa">Empresa</Label>
              <Input
                id="empresa"
                name="empresa"
                value={formData.empresa}
                onChange={handleChange}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="origen">Origen del lead</Label>
                <Select
                  value={formData.origen}
                  onValueChange={(value) => setFormData({ ...formData, origen: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="¿Cómo nos encontró?" />
                  </SelectTrigger>
                  <SelectContent>
                    {leadOrigins.map((origen) => (
                      <SelectItem key={origen} value={origen}>
                        {origen}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="tipo_caso">Tipo de caso</Label>
                <Input
                  id="tipo_caso"
                  name="tipo_caso"
                  value={formData.tipo_caso}
                  onChange={handleChange}
                  placeholder="Ej: Civil, Laboral, Penal"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="valor_estimado">Valor estimado (COP)</Label>
              <Input
                id="valor_estimado"
                name="valor_estimado"
                type="number"
                value={formData.valor_estimado}
                onChange={handleChange}
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="mensaje">Mensaje o descripción del caso</Label>
              <Textarea
                id="mensaje"
                name="mensaje"
                value={formData.mensaje}
                onChange={handleChange}
                rows={4}
              />
            </div>

            <div className="flex gap-4 pt-4">
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  "Guardar lead"
                )}
              </Button>
              <Button type="button" variant="outline" asChild>
                <Link href="/dashboard/leads">Cancelar</Link>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
