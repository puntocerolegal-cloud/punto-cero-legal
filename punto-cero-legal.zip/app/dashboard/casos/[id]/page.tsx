import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Edit, User, Calendar, FileText, Receipt, AlertCircle, Gavel } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"

const statusLabels: Record<string, string> = {
  nuevo: "Nuevo",
  en_tramite: "En trámite",
  admitido: "Admitido",
  notificado: "Notificado",
  contestado: "Contestado",
  pruebas: "Pruebas",
  alegatos: "Alegatos",
  fallo_primera_instancia: "Fallo 1ra instancia",
  apelacion: "Apelación",
  fallo_segunda_instancia: "Fallo 2da instancia",
  casacion: "Casación",
  ejecutoriado: "Ejecutoriado",
  archivado: "Archivado",
}

const statusColors: Record<string, string> = {
  nuevo: "bg-blue-100 text-blue-800",
  en_tramite: "bg-yellow-100 text-yellow-800",
  admitido: "bg-green-100 text-green-800",
  ejecutoriado: "bg-emerald-100 text-emerald-800",
  archivado: "bg-gray-100 text-gray-800",
}

export default async function CasoDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()
  
  const { data: caso } = await supabase
    .from("cases")
    .select("*, client:clients(nombre_completo), abogado:profiles(first_name, last_name)")
    .eq("id", id)
    .single()

  if (!caso) {
    notFound()
  }

  const [{ data: activities }, { data: documents }, { data: tasks }] = await Promise.all([
    supabase.from("case_activities").select("*").eq("case_id", id).order("fecha_actuacion", { ascending: false }).limit(10),
    supabase.from("documents").select("*").eq("case_id", id).order("created_at", { ascending: false }).limit(5),
    supabase.from("tasks").select("*").eq("case_id", id).eq("completed", false).order("due_date", { ascending: true }).limit(5),
  ])

  const formatCurrency = (amount: number | null) => {
    if (!amount) return "No definida"
    return new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", minimumFractionDigits: 0 }).format(amount)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard/casos">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold tracking-tight">{caso.radicado || "Sin radicado"}</h1>
              <Badge className={statusColors[caso.status] || "bg-gray-100"}>
                {statusLabels[caso.status]}
              </Badge>
            </div>
            <p className="text-muted-foreground">{caso.tipo_proceso || "Tipo de proceso no definido"}</p>
          </div>
        </div>
        <Button asChild>
          <Link href={`/dashboard/casos/${id}/editar`}>
            <Edit className="mr-2 h-4 w-4" />
            Editar
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Información del caso</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-sm text-muted-foreground">Cliente</p>
                <Link href={`/dashboard/clientes/${caso.client_id}`} className="font-medium text-primary hover:underline">
                  {caso.client?.nombre_completo || "No asignado"}
                </Link>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Abogado asignado</p>
                <p className="font-medium">
                  {caso.abogado ? `${caso.abogado.first_name} ${caso.abogado.last_name}` : "No asignado"}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Despacho</p>
                <p className="font-medium">{caso.despacho || "No definido"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Jurisdicción</p>
                <p className="font-medium">{caso.jurisdiccion}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Especialidad</p>
                <p className="font-medium">{caso.especialidad || "No definida"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Cuantía</p>
                <p className="font-medium">{formatCurrency(caso.cuantia)}</p>
              </div>
            </div>

            <Separator />

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-sm text-muted-foreground">Demandante</p>
                <p className="font-medium">{caso.demandante || "No definido"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Demandado</p>
                <p className="font-medium">{caso.demandado || "No definido"}</p>
              </div>
            </div>

            {caso.descripcion && (
              <>
                <Separator />
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Descripción del caso</p>
                  <p className="text-sm">{caso.descripcion}</p>
                </div>
              </>
            )}

            <Separator />

            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Fecha de radicación</p>
                <p className="font-medium">
                  {caso.fecha_radicacion
                    ? new Date(caso.fecha_radicacion).toLocaleDateString("es-CO", { year: "numeric", month: "long", day: "numeric" })
                    : "No definida"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Tareas pendientes
                </CardTitle>
                <Badge variant="secondary">{tasks?.length || 0}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {tasks && tasks.length > 0 ? (
                <div className="space-y-2">
                  {tasks.map((task) => (
                    <div key={task.id} className="p-2 rounded-lg border text-sm">
                      <p className="font-medium">{task.title}</p>
                      {task.due_date && (
                        <p className="text-muted-foreground text-xs">
                          Vence: {new Date(task.due_date).toLocaleDateString("es-CO")}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No hay tareas pendientes</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Documentos
                </CardTitle>
                <Badge variant="secondary">{documents?.length || 0}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {documents && documents.length > 0 ? (
                <div className="space-y-2">
                  {documents.map((doc) => (
                    <Link
                      key={doc.id}
                      href={`/dashboard/documentos/${doc.id}`}
                      className="block p-2 rounded-lg hover:bg-muted text-sm"
                    >
                      <p className="font-medium">{doc.title}</p>
                      <p className="text-muted-foreground text-xs">{doc.document_type}</p>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No hay documentos</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Gavel className="h-4 w-4" />
                Últimas actuaciones
              </CardTitle>
            </CardHeader>
            <CardContent>
              {activities && activities.length > 0 ? (
                <div className="space-y-3">
                  {activities.map((activity) => (
                    <div key={activity.id} className="border-l-2 border-primary/30 pl-3 text-sm">
                      <p className="font-medium">{activity.tipo_actuacion}</p>
                      <p className="text-muted-foreground text-xs">
                        {new Date(activity.fecha_actuacion).toLocaleDateString("es-CO")}
                      </p>
                      {activity.descripcion && (
                        <p className="text-xs mt-1">{activity.descripcion}</p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No hay actuaciones registradas</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
