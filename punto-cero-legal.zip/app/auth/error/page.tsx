import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle } from "lucide-react"

export default function AuthErrorPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <div className="bg-destructive/10 p-3 rounded-full">
              <AlertTriangle className="h-8 w-8 text-destructive" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold">Error de autenticación</CardTitle>
          <CardDescription>
            Hubo un problema al verificar tu cuenta
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            El enlace puede haber expirado o ya fue utilizado. Por favor intenta iniciar sesión o solicita un nuevo enlace de verificación.
          </p>
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          <Button asChild className="w-full">
            <Link href="/auth/login">Iniciar sesión</Link>
          </Button>
          <Button asChild variant="outline" className="w-full">
            <Link href="/auth/registro">Crear nueva cuenta</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
