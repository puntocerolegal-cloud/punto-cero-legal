import { createClient } from "@/lib/supabase/server"
import { CasesTable } from "./cases-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function CasosPage() {
  const supabase = await createClient()
  const { data: cases } = await supabase
    .from("cases")
    .select("*, client:clients(nombre_completo), abogado:profiles(first_name, last_name)")
    .order("created_at", { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Casos</h1>
          <p className="text-muted-foreground">Gestiona los procesos judiciales de tu firma</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/casos/nuevo">
            <Plus className="mr-2 h-4 w-4" />
            Nuevo caso
          </Link>
        </Button>
      </div>

      <CasesTable cases={cases || []} />
    </div>
  )
}
