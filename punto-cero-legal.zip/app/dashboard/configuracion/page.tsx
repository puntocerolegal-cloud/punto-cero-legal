import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Building, User, Users } from "lucide-react"
import { ProfileForm } from "./profile-form"
import { FirmForm } from "./firm-form"

export default async function ConfiguracionPage() {
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("*, law_firm:law_firms(*)")
    .eq("id", user.id)
    .single()

  const { data: teamMembers } = await supabase
    .from("profiles")
    .select("*")
    .eq("law_firm_id", profile?.law_firm_id)
    .neq("id", user.id)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configuración</h1>
        <p className="text-muted-foreground">Administra tu perfil y configuración de la firma</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Mi perfil
            </CardTitle>
            <CardDescription>Tu información personal</CardDescription>
          </CardHeader>
          <CardContent>
            <ProfileForm profile={profile} userEmail={user.email || ""} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Información de la firma
            </CardTitle>
            <CardDescription>Datos de tu firma legal</CardDescription>
          </CardHeader>
          <CardContent>
            <FirmForm firm={profile?.law_firm} isAdmin={profile?.role === "admin"} />
          </CardContent>
        </Card>
      </div>

      {profile?.role === "admin" && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Equipo
            </CardTitle>
            <CardDescription>Miembros de tu firma</CardDescription>
          </CardHeader>
          <CardContent>
            {teamMembers && teamMembers.length > 0 ? (
              <div className="space-y-4">
                {teamMembers.map((member) => (
                  <div key={member.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">
                        {member.first_name} {member.last_name}
                      </p>
                      <p className="text-sm text-muted-foreground capitalize">{member.role}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${member.is_active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`}>
                      {member.is_active ? "Activo" : "Inactivo"}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No hay otros miembros en tu firma</p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
