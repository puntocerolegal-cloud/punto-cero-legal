import { createClient } from "@/lib/supabase/server"
import { DocumentsTable } from "./documents-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function DocumentosPage() {
  const supabase = await createClient()
  const { data: documents } = await supabase
    .from("documents")
    .select("*, case:cases(radicado), client:clients(nombre_completo)")
    .order("created_at", { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Documentos</h1>
          <p className="text-muted-foreground">Gestiona los documentos legales</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/documentos/nuevo">
            <Plus className="mr-2 h-4 w-4" />
            Subir documento
          </Link>
        </Button>
      </div>

      <DocumentsTable documents={documents || []} />
    </div>
  )
}
