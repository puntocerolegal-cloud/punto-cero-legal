"use client"

import { useState } from "react"
import Link from "next/link"
import { Case } from "@/lib/types"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Eye, Edit } from "lucide-react"

interface CasesTableProps {
  cases: (Case & { client?: { nombre_completo: string }; abogado?: { first_name: string; last_name: string } })[]
}

const statusLabels: Record<string, string> = {
  nuevo: "Nuevo",
  en_tramite: "En trámite",
  admitido: "Admitido",
  notificado: "Notificado",
  contestado: "Contestado",
  pruebas: "Pruebas",
  alegatos: "Alegatos",
  fallo_primera_instancia: "Fallo 1ra",
  apelacion: "Apelación",
  fallo_segunda_instancia: "Fallo 2da",
  casacion: "Casación",
  ejecutoriado: "Ejecutoriado",
  archivado: "Archivado",
}

const statusColors: Record<string, string> = {
  nuevo: "bg-blue-100 text-blue-800",
  en_tramite: "bg-yellow-100 text-yellow-800",
  admitido: "bg-green-100 text-green-800",
  notificado: "bg-purple-100 text-purple-800",
  contestado: "bg-indigo-100 text-indigo-800",
  pruebas: "bg-orange-100 text-orange-800",
  alegatos: "bg-pink-100 text-pink-800",
  fallo_primera_instancia: "bg-teal-100 text-teal-800",
  apelacion: "bg-red-100 text-red-800",
  fallo_segunda_instancia: "bg-cyan-100 text-cyan-800",
  casacion: "bg-amber-100 text-amber-800",
  ejecutoriado: "bg-emerald-100 text-emerald-800",
  archivado: "bg-gray-100 text-gray-800",
}

export function CasesTable({ cases }: CasesTableProps) {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const filteredCases = cases.filter((caso) => {
    const matchesSearch =
      caso.radicado?.toLowerCase().includes(search.toLowerCase()) ||
      caso.client?.nombre_completo.toLowerCase().includes(search.toLowerCase()) ||
      caso.tipo_proceso?.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = statusFilter === "all" || caso.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar por radicado, cliente o tipo..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            {Object.entries(statusLabels).map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Radicado</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>Tipo de proceso</TableHead>
              <TableHead>Despacho</TableHead>
              <TableHead>Abogado</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCases.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  No se encontraron casos
                </TableCell>
              </TableRow>
            ) : (
              filteredCases.map((caso) => (
                <TableRow key={caso.id}>
                  <TableCell className="font-medium">{caso.radicado || "-"}</TableCell>
                  <TableCell>{caso.client?.nombre_completo || "-"}</TableCell>
                  <TableCell>{caso.tipo_proceso || "-"}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{caso.despacho || "-"}</TableCell>
                  <TableCell>
                    {caso.abogado
                      ? `${caso.abogado.first_name} ${caso.abogado.last_name}`
                      : "-"}
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[caso.status]}>
                      {statusLabels[caso.status] || caso.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/dashboard/casos/${caso.id}`}>
                          <Eye className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/dashboard/casos/${caso.id}/editar`}>
                          <Edit className="h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
