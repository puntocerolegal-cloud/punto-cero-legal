import { createClient } from "@/lib/supabase/server"
import { LeadsTable } from "./leads-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function LeadsPage() {
  const supabase = await createClient()
  const { data: leads } = await supabase
    .from("leads")
    .select("*, assignee:profiles(first_name, last_name)")
    .order("created_at", { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Leads</h1>
          <p className="text-muted-foreground">Gestiona los prospectos de clientes</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/leads/nuevo">
            <Plus className="mr-2 h-4 w-4" />
            Nuevo lead
          </Link>
        </Button>
      </div>

      <LeadsTable leads={leads || []} />
    </div>
  )
}
