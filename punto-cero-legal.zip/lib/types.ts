export type UserRole = "admin" | "abogado" | "asistente" | "cliente"
export type SubscriptionPlan = "basico" | "profesional" | "empresarial"
export type CaseStatus = "nuevo" | "en_tramite" | "admitido" | "notificado" | "contestado" | "pruebas" | "alegatos" | "fallo_primera_instancia" | "apelacion" | "fallo_segunda_instancia" | "casacion" | "ejecutoriado" | "archivado"
export type DocumentType = "demanda" | "contestacion" | "memorial" | "poder" | "auto" | "sentencia" | "recurso" | "prueba" | "notificacion" | "acta" | "contrato" | "otro"
export type PaymentStatus = "pendiente" | "pagado" | "vencido" | "cancelado"
export type MeetingStatus = "programada" | "confirmada" | "completada" | "cancelada" | "reprogramada"
export type LeadStatus = "nuevo" | "contactado" | "calificado" | "propuesta" | "negociacion" | "ganado" | "perdido"

export interface LawFirm {
  id: string
  name: string
  nit: string | null
  address: string | null
  city: string
  phone: string | null
  email: string | null
  subscription_plan: SubscriptionPlan
  subscription_start: string
  subscription_end: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Profile {
  id: string
  law_firm_id: string | null
  role: UserRole
  first_name: string | null
  last_name: string | null
  cedula: string | null
  phone: string | null
  tarjeta_profesional: string | null
  especialidad: string | null
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Client {
  id: string
  law_firm_id: string
  profile_id: string | null
  tipo_persona: "natural" | "juridica"
  nombre_completo: string
  cedula_nit: string | null
  email: string | null
  telefono: string | null
  direccion: string | null
  ciudad: string
  notas: string | null
  created_at: string
  updated_at: string
}

export interface Case {
  id: string
  law_firm_id: string
  client_id: string
  abogado_id: string | null
  radicado: string | null
  despacho: string | null
  tipo_proceso: string | null
  jurisdiccion: string
  especialidad: string | null
  demandante: string | null
  demandado: string | null
  cuantia: number | null
  status: CaseStatus
  fecha_radicacion: string | null
  fecha_ultima_actuacion: string | null
  descripcion: string | null
  notas_internas: string | null
  created_at: string
  updated_at: string
  client?: Client
  abogado?: Profile
}

export interface CaseActivity {
  id: string
  case_id: string
  user_id: string | null
  tipo_actuacion: string
  fecha_actuacion: string
  descripcion: string
  es_termino: boolean
  fecha_vencimiento: string | null
  completada: boolean
  created_at: string
}

export interface Document {
  id: string
  case_id: string | null
  client_id: string | null
  law_firm_id: string
  uploaded_by: string | null
  document_type: DocumentType
  title: string
  description: string | null
  file_url: string | null
  file_name: string | null
  file_size: number | null
  mime_type: string | null
  version: number
  is_confidential: boolean
  created_at: string
  updated_at: string
}

export interface Invoice {
  id: string
  law_firm_id: string
  client_id: string
  case_id: string | null
  numero_factura: string | null
  concepto: string
  subtotal: number
  iva: number
  total: number
  status: PaymentStatus
  fecha_emision: string
  fecha_vencimiento: string | null
  fecha_pago: string | null
  metodo_pago: string | null
  notas: string | null
  created_at: string
  updated_at: string
  client?: Client
}

export interface Meeting {
  id: string
  law_firm_id: string
  client_id: string | null
  case_id: string | null
  organizer_id: string
  title: string
  description: string | null
  start_time: string
  end_time: string
  location: string | null
  is_virtual: boolean
  meeting_url: string | null
  status: MeetingStatus
  reminder_sent: boolean
  notas: string | null
  created_at: string
  updated_at: string
  client?: Client
}

export interface Task {
  id: string
  law_firm_id: string
  case_id: string | null
  assigned_to: string | null
  created_by: string
  title: string
  description: string | null
  priority: "baja" | "media" | "alta" | "urgente"
  due_date: string | null
  completed: boolean
  completed_at: string | null
  created_at: string
  updated_at: string
  case?: Case
  assignee?: Profile
}

export interface Lead {
  id: string
  law_firm_id: string
  assigned_to: string | null
  nombre: string
  email: string | null
  telefono: string | null
  empresa: string | null
  origen: string | null
  tipo_caso: string | null
  mensaje: string | null
  status: LeadStatus
  valor_estimado: number | null
  proxima_accion: string | null
  fecha_proxima_accion: string | null
  convertido_cliente_id: string | null
  created_at: string
  updated_at: string
}

export interface Notification {
  id: string
  user_id: string
  title: string
  message: string
  type: string
  link: string | null
  read: boolean
  created_at: string
}
