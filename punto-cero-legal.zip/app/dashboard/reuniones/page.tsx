import { createClient } from "@/lib/supabase/server"
import { ReunionesTable } from "./reuniones-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function ReunionesPage() {
  const supabase = await createClient()
  const { data: meetings } = await supabase
    .from("meetings")
    .select("*, client:clients(nombre_completo)")
    .order("start_time", { ascending: true })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reuniones</h1>
          <p className="text-muted-foreground">Gestiona tu agenda de reuniones y citas</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/reuniones/nueva">
            <Plus className="mr-2 h-4 w-4" />
            Nueva reunión
          </Link>
        </Button>
      </div>

      <ReunionesTable meetings={meetings || []} />
    </div>
  )
}
