"use client"

import { useState } from "react"
import Link from "next/link"
import { Invoice } from "@/lib/types"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Eye, Edit } from "lucide-react"

interface FacturasTableProps {
  invoices: (Invoice & { client?: { nombre_completo: string } })[]
}

const statusLabels: Record<string, string> = {
  pendiente: "Pendiente",
  pagado: "Pagado",
  vencido: "Vencido",
  cancelado: "Cancelado",
}

const statusColors: Record<string, string> = {
  pendiente: "bg-yellow-100 text-yellow-800",
  pagado: "bg-green-100 text-green-800",
  vencido: "bg-red-100 text-red-800",
  cancelado: "bg-gray-100 text-gray-800",
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    minimumFractionDigits: 0,
  }).format(amount)
}

export function FacturasTable({ invoices }: FacturasTableProps) {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const filteredInvoices = invoices.filter((invoice) => {
    const matchesSearch =
      invoice.numero_factura?.toLowerCase().includes(search.toLowerCase()) ||
      invoice.client?.nombre_completo.toLowerCase().includes(search.toLowerCase()) ||
      invoice.concepto.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totals = {
    pendiente: filteredInvoices.filter((i) => i.status === "pendiente").reduce((sum, i) => sum + i.total, 0),
    pagado: filteredInvoices.filter((i) => i.status === "pagado").reduce((sum, i) => sum + i.total, 0),
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 max-w-md">
        <div className="p-4 rounded-lg border bg-yellow-50">
          <p className="text-sm text-yellow-800">Por cobrar</p>
          <p className="text-xl font-bold text-yellow-900">{formatCurrency(totals.pendiente)}</p>
        </div>
        <div className="p-4 rounded-lg border bg-green-50">
          <p className="text-sm text-green-800">Cobrado</p>
          <p className="text-xl font-bold text-green-900">{formatCurrency(totals.pagado)}</p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar por número, cliente o concepto..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            {Object.entries(statusLabels).map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>No. Factura</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>Concepto</TableHead>
              <TableHead>Fecha emisión</TableHead>
              <TableHead>Vencimiento</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInvoices.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                  No se encontraron facturas
                </TableCell>
              </TableRow>
            ) : (
              filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell className="font-medium">{invoice.numero_factura || "-"}</TableCell>
                  <TableCell>{invoice.client?.nombre_completo || "-"}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{invoice.concepto}</TableCell>
                  <TableCell>{new Date(invoice.fecha_emision).toLocaleDateString("es-CO")}</TableCell>
                  <TableCell>
                    {invoice.fecha_vencimiento
                      ? new Date(invoice.fecha_vencimiento).toLocaleDateString("es-CO")
                      : "-"}
                  </TableCell>
                  <TableCell className="text-right font-medium">{formatCurrency(invoice.total)}</TableCell>
                  <TableCell>
                    <Badge className={statusColors[invoice.status]}>
                      {statusLabels[invoice.status]}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/dashboard/facturas/${invoice.id}`}>
                          <Eye className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/dashboard/facturas/${invoice.id}/editar`}>
                          <Edit className="h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
