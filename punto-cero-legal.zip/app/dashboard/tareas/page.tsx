import { createClient } from "@/lib/supabase/server"
import { TasksTable } from "./tasks-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function TareasPage() {
  const supabase = await createClient()
  const { data: tasks } = await supabase
    .from("tasks")
    .select("*, case:cases(radicado), assignee:profiles(first_name, last_name)")
    .order("due_date", { ascending: true })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tareas</h1>
          <p className="text-muted-foreground">Gestiona las tareas pendientes</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/tareas/nueva">
            <Plus className="mr-2 h-4 w-4" />
            Nueva tarea
          </Link>
        </Button>
      </div>

      <TasksTable tasks={tasks || []} />
    </div>
  )
}
