import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Briefcase, Receipt, Calendar, CheckSquare, AlertTriangle, TrendingUp, Clock } from "lucide-react"
import Link from "next/link"

async function getDashboardStats() {
  const supabase = await createClient()
  
  const [
    { count: clientsCount },
    { count: casesCount },
    { count: pendingInvoicesCount },
    { count: todayMeetingsCount },
    { count: pendingTasksCount },
    { data: recentCases },
    { data: upcomingTasks },
  ] = await Promise.all([
    supabase.from("clients").select("*", { count: "exact", head: true }),
    supabase.from("cases").select("*", { count: "exact", head: true }),
    supabase.from("invoices").select("*", { count: "exact", head: true }).eq("status", "pendiente"),
    supabase.from("meetings").select("*", { count: "exact", head: true })
      .gte("start_time", new Date().toISOString().split("T")[0])
      .lt("start_time", new Date(Date.now() + 86400000).toISOString().split("T")[0]),
    supabase.from("tasks").select("*", { count: "exact", head: true }).eq("completed", false),
    supabase.from("cases").select("*, client:clients(nombre_completo)").order("created_at", { ascending: false }).limit(5),
    supabase.from("tasks").select("*").eq("completed", false).order("due_date", { ascending: true }).limit(5),
  ])

  return {
    clientsCount: clientsCount || 0,
    casesCount: casesCount || 0,
    pendingInvoicesCount: pendingInvoicesCount || 0,
    todayMeetingsCount: todayMeetingsCount || 0,
    pendingTasksCount: pendingTasksCount || 0,
    recentCases: recentCases || [],
    upcomingTasks: upcomingTasks || [],
  }
}

const statusLabels: Record<string, string> = {
  nuevo: "Nuevo",
  en_tramite: "En trámite",
  admitido: "Admitido",
  notificado: "Notificado",
  contestado: "Contestado",
  pruebas: "Pruebas",
  alegatos: "Alegatos",
  fallo_primera_instancia: "Fallo 1ra instancia",
  apelacion: "Apelación",
  fallo_segunda_instancia: "Fallo 2da instancia",
  casacion: "Casación",
  ejecutoriado: "Ejecutoriado",
  archivado: "Archivado",
}

const priorityColors: Record<string, string> = {
  baja: "bg-gray-100 text-gray-800",
  media: "bg-blue-100 text-blue-800",
  alta: "bg-orange-100 text-orange-800",
  urgente: "bg-red-100 text-red-800",
}

export default async function DashboardPage() {
  const stats = await getDashboardStats()

  const statCards = [
    { title: "Clientes", value: stats.clientsCount, icon: Users, href: "/dashboard/clientes", color: "text-blue-600" },
    { title: "Casos activos", value: stats.casesCount, icon: Briefcase, href: "/dashboard/casos", color: "text-green-600" },
    { title: "Facturas pendientes", value: stats.pendingInvoicesCount, icon: Receipt, href: "/dashboard/facturas", color: "text-orange-600" },
    { title: "Reuniones hoy", value: stats.todayMeetingsCount, icon: Calendar, href: "/dashboard/reuniones", color: "text-purple-600" },
    { title: "Tareas pendientes", value: stats.pendingTasksCount, icon: CheckSquare, href: "/dashboard/tareas", color: "text-red-600" },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Resumen de tu firma legal</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        {statCards.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Casos recientes
            </CardTitle>
            <CardDescription>Últimos casos agregados</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.recentCases.length === 0 ? (
              <p className="text-muted-foreground text-sm">No hay casos registrados</p>
            ) : (
              <div className="space-y-4">
                {stats.recentCases.map((caso: any) => (
                  <Link
                    key={caso.id}
                    href={`/dashboard/casos/${caso.id}`}
                    className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted transition-colors"
                  >
                    <div>
                      <p className="font-medium">{caso.radicado || "Sin radicado"}</p>
                      <p className="text-sm text-muted-foreground">
                        {caso.client?.nombre_completo || "Cliente no asignado"}
                      </p>
                    </div>
                    <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary">
                      {statusLabels[caso.status] || caso.status}
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Tareas próximas
            </CardTitle>
            <CardDescription>Tareas pendientes por vencer</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.upcomingTasks.length === 0 ? (
              <p className="text-muted-foreground text-sm">No hay tareas pendientes</p>
            ) : (
              <div className="space-y-4">
                {stats.upcomingTasks.map((task: any) => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                  >
                    <div>
                      <p className="font-medium">{task.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {task.due_date
                          ? new Date(task.due_date).toLocaleDateString("es-CO")
                          : "Sin fecha límite"}
                      </p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${priorityColors[task.priority]}`}>
                      {task.priority}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
