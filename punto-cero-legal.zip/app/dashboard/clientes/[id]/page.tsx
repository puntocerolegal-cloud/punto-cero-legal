import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Edit, Building, Mail, Phone, MapPin, User, Calendar, FileText, Receipt, Briefcase } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"

export default async function ClienteDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()
  
  const { data: client } = await supabase
    .from("clients")
    .select("*")
    .eq("id", id)
    .single()

  if (!client) {
    notFound()
  }

  const [{ data: cases }, { data: invoices }, { data: documents }] = await Promise.all([
    supabase.from("cases").select("*").eq("client_id", id).order("created_at", { ascending: false }).limit(5),
    supabase.from("invoices").select("*").eq("client_id", id).order("created_at", { ascending: false }).limit(5),
    supabase.from("documents").select("*").eq("client_id", id).order("created_at", { ascending: false }).limit(5),
  ])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard/clientes">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{client.nombre_completo}</h1>
            <p className="text-muted-foreground">
              {client.tipo_persona === "juridica" ? "Persona jurídica" : "Persona natural"}
            </p>
          </div>
        </div>
        <Button asChild>
          <Link href={`/dashboard/clientes/${id}/editar`}>
            <Edit className="mr-2 h-4 w-4" />
            Editar
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Información del cliente</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex items-center gap-3">
                {client.tipo_persona === "juridica" ? (
                  <Building className="h-5 w-5 text-muted-foreground" />
                ) : (
                  <User className="h-5 w-5 text-muted-foreground" />
                )}
                <div>
                  <p className="text-sm text-muted-foreground">
                    {client.tipo_persona === "juridica" ? "NIT" : "Cédula"}
                  </p>
                  <p className="font-medium">{client.cedula_nit || "No registrada"}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{client.email || "No registrado"}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Teléfono</p>
                  <p className="font-medium">{client.telefono || "No registrado"}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Ciudad</p>
                  <p className="font-medium">{client.ciudad}</p>
                </div>
              </div>
            </div>
            {client.direccion && (
              <div>
                <p className="text-sm text-muted-foreground">Dirección</p>
                <p className="font-medium">{client.direccion}</p>
              </div>
            )}
            {client.notas && (
              <div>
                <p className="text-sm text-muted-foreground">Notas</p>
                <p className="font-medium">{client.notas}</p>
              </div>
            )}
            <Separator />
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Cliente desde</p>
                <p className="font-medium">
                  {new Date(client.created_at).toLocaleDateString("es-CO", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Briefcase className="h-4 w-4" />
                  Casos
                </CardTitle>
                <Badge variant="secondary">{cases?.length || 0}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {cases && cases.length > 0 ? (
                <div className="space-y-2">
                  {cases.map((caso) => (
                    <Link
                      key={caso.id}
                      href={`/dashboard/casos/${caso.id}`}
                      className="block p-2 rounded-lg hover:bg-muted text-sm"
                    >
                      <p className="font-medium">{caso.radicado || "Sin radicado"}</p>
                      <p className="text-muted-foreground text-xs">{caso.tipo_proceso}</p>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No hay casos registrados</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Receipt className="h-4 w-4" />
                  Facturas
                </CardTitle>
                <Badge variant="secondary">{invoices?.length || 0}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {invoices && invoices.length > 0 ? (
                <div className="space-y-2">
                  {invoices.map((invoice) => (
                    <Link
                      key={invoice.id}
                      href={`/dashboard/facturas/${invoice.id}`}
                      className="block p-2 rounded-lg hover:bg-muted text-sm"
                    >
                      <p className="font-medium">{invoice.numero_factura}</p>
                      <p className="text-muted-foreground text-xs">
                        {new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", minimumFractionDigits: 0 }).format(invoice.total)}
                      </p>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No hay facturas registradas</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
