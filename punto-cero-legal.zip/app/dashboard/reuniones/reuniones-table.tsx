"use client"

import { useState } from "react"
import Link from "next/link"
import { Meeting } from "@/lib/types"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Eye, Edit, Video, MapPin } from "lucide-react"

interface ReunionesTableProps {
  meetings: (Meeting & { client?: { nombre_completo: string } })[]
}

const statusLabels: Record<string, string> = {
  programada: "Programada",
  confirmada: "Confirmada",
  completada: "Completada",
  cancelada: "Cancelada",
  reprogramada: "Reprogramada",
}

const statusColors: Record<string, string> = {
  programada: "bg-blue-100 text-blue-800",
  confirmada: "bg-green-100 text-green-800",
  completada: "bg-gray-100 text-gray-800",
  cancelada: "bg-red-100 text-red-800",
  reprogramada: "bg-yellow-100 text-yellow-800",
}

export function ReunionesTable({ meetings }: ReunionesTableProps) {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const filteredMeetings = meetings.filter((meeting) => {
    const matchesSearch =
      meeting.title.toLowerCase().includes(search.toLowerCase()) ||
      meeting.client?.nombre_completo.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = statusFilter === "all" || meeting.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString)
    return {
      date: date.toLocaleDateString("es-CO", { weekday: "short", day: "numeric", month: "short" }),
      time: date.toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" }),
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar por título o cliente..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            {Object.entries(statusLabels).map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Título</TableHead>
              <TableHead>Cliente</TableHead>
              <TableHead>Fecha</TableHead>
              <TableHead>Hora</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMeetings.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  No se encontraron reuniones
                </TableCell>
              </TableRow>
            ) : (
              filteredMeetings.map((meeting) => {
                const { date, time } = formatDateTime(meeting.start_time)
                const endTime = formatDateTime(meeting.end_time).time
                return (
                  <TableRow key={meeting.id}>
                    <TableCell className="font-medium">{meeting.title}</TableCell>
                    <TableCell>{meeting.client?.nombre_completo || "-"}</TableCell>
                    <TableCell>{date}</TableCell>
                    <TableCell>{time} - {endTime}</TableCell>
                    <TableCell>
                      {meeting.is_virtual ? (
                        <Badge variant="outline" className="gap-1">
                          <Video className="h-3 w-3" />
                          Virtual
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="gap-1">
                          <MapPin className="h-3 w-3" />
                          Presencial
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={statusColors[meeting.status]}>
                        {statusLabels[meeting.status]}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/dashboard/reuniones/${meeting.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/dashboard/reuniones/${meeting.id}/editar`}>
                            <Edit className="h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
